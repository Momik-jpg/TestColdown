# Barrierefreie Bedienung

## Schrift und Kontrast

Die App übernimmt die Android-Schriftgröße. Unter „Ansicht & Bedienung“ kannst du zusätzlich den Modus für bessere Lesbarkeit und höheren Kontrast aktivieren. In diesem Modus werden dekorative Banner ausgeblendet. Heller, dunkler und systemabhängiger Modus sind verfügbar. Texte stehen auf deckenden Flächen, nie im Bild.

## Navigation und Screenreader

Die fünf Hauptbereiche sind Prüfungen, Stundenplan, Agenda, Noten und Optionen. Bei wenig Platz oder großer Schrift werden ihre beschrifteten Schaltflächen in mehrere Zeilen angeordnet. Du kannst Tabs in den Einstellungen ausblenden und deine Startansicht bestimmen. Aktive Tabs, Filter und Schalter geben ihren Zustand an TalkBack weiter. Abschnittstitel sind als Überschriften ausgezeichnet. Dekorative Illustrationen werden nicht vorgelesen.

Aktiviere TalkBack in den Android-Bedienungshilfen. Wische zum nächsten Element und tippe doppelt zum Ausführen. Bedienelemente lassen sich über ihre Beschriftung finden. Fehlermeldungen in Eingabefeldern erläutern die notwendige Korrektur. Zeiten, Status und Raumänderungen werden auch als Text angegeben.

## Kleine Displays und große Schrift

Eingabefelder und Aktionspaare wechseln bei wenig Platz von nebeneinander zu untereinander. Inhalte und die Hinweise zu Datenschutz und Lizenzen lassen sich scrollen. Bedienflächen haben mindestens 48 dp als Zielgröße. Du kannst Dokumenttexte auswählen und kopieren. Bei besonders großer Schrift kann mehr Scrollen nötig sein.

## Widgets

Widget-Größe und Android-Schriftgröße bestimmen die Zahl sichtbarer Zeilen. Vergrößere ein Widget, wenn du mehr Termine sehen möchtest. „Kompakte Ansicht“, „Raum anzeigen“ und „Countdown anzeigen“ sind pro Widget einstellbar. „Persönliche Details verbergen“ entfernt persönliche Titel und Räume auch aus den vorgelesenen Widget-Zeilen. Datum, Uhrzeit und Terminart bleiben sichtbar. Die konkrete Darstellung und Fokussteuerung hängen auch von deinem Launcher ab.

## Unterstützung und Grenzen

Kontraste, schmale Ansichten, große Schrift, Schalter, Tabs und Widget-Zeilen werden mit automatisierten Tests geprüft. Das ersetzt keine Prüfung mit TalkBack, Schalterzugriff, Tastatur und unterschiedlichen Launchern auf echten Geräten. Eine vollständige Barrierefreiheits-Zertifizierung ist nicht erfolgt. Probleme kannst du unter https://github.com/Momik-jpg/TestColdown/issues melden. Nenne Android-Version, Schriftgröße, Launcher und den betroffenen Schritt, ohne private Kalenderdaten zu veröffentlichen.
